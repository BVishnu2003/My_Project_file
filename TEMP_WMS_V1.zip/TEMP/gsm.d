gsm.o: gsm.c
gsm.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
gsm.o: uart.h
gsm.o: gsm.h
gsm.o: timer.h
