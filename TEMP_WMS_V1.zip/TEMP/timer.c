#include <LPC21xx.h>
#include "config.h"
#include "timer.h"

void Timer0_Init(void)
{
    T0TCR = 0x02;          // Reset Timer0

    T0PR = 15000 - 1;      // Prescaler for 1 ms
                            // Assuming PCLK = 15 MHz

    T0TCR = 0x01;          // Enable Timer0
}

void Timer0_Delay_ms(unsigned int ms)
{
    unsigned int i;

    for (i = 0; i < ms; i++)
    {
        T0TC = 0;          // Reset timer counter
        T0TCR = 0x01;       // Start Timer0

        while (T0TC < 1);  // Wait approximately 1 ms

        T0TCR = 0x00;      // Stop Timer0
    }
}
