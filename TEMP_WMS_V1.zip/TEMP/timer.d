timer.o: timer.c
timer.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
timer.o: config.h
timer.o: timer.h
