lcd.o: lcd.c
lcd.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
lcd.o: lcd.h
lcd.o: timer.h
