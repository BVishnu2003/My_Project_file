#include "config.h"
#include "timer.h"
#include "adc.h"
#include "lcd.h"
#include "sensor.h"
#include "uart.h"
#include "gsm.h"

int main(void)
{
    float temperature;
    unsigned int rain;
    unsigned int soil;
    unsigned int light;

    unsigned char temp_alert_sent = 0;
    unsigned char rain_alert_sent = 0;

    /* Initialize peripherals */
    Timer0_Init();
    LCD_Init();
    ADC_Init();
    UART0_INIT();

    /* Initialize GSM */
    GSM_INIT();

    /* Power ON Title */
    LCD_Clear();

    LCD_String("WEATHER MONITOR");
    Timer0_Delay_ms(1000);

    LCD_Clear();
    LCD_String("SYSTEM STARTING");

    Timer0_Delay_ms(1000);

    while (1)
    {
        /* Read sensors */
        temperature = Read_Temperature();
        rain = Read_RainSensor();
        soil = Read_SoilMoisture();
        light = Read_Light();

        /* Display temperature */
        LCD_Clear();

        LCD_String("TEMP:");
        LCD_PrintFloat(temperature);
        LCD_Data('C');

        LCD_SetCursor(2, 1);
        LCD_String("RAIN:");
        LCD_PrintNumber(rain);
        LCD_Data('%');

        LCD_SetCursor(3, 1);
        LCD_String("SOIL:");
        LCD_PrintNumber(soil);
        LCD_Data('%');

        LCD_SetCursor(4, 1);
        LCD_String("LIGHT:");
        LCD_PrintNumber(light);
        LCD_Data('%');

        /* =========================================
           HIGH TEMPERATURE ALERT
           ========================================= */

        if (temperature >= 35.0)
        {
            if (temp_alert_sent == 0)
            {
                GSM_SEND_SMS("HIGH TEMPERATURE ALERT!");

                temp_alert_sent = 1;
            }
        }
        else
        {
            /* Allow another alert after temperature
               comes back below the limit */
            temp_alert_sent = 0;
        }

        /* =========================================
           RAIN ALERT
           ========================================= */

        if (rain <= 30)
        {
            if (rain_alert_sent == 0)
            {
                GSM_SEND_SMS("RAIN ALERT! RAIN DETECTED.");

                rain_alert_sent = 1;
            }
        }
        else
        {
            /* Allow another alert after rain condition
               goes back to normal */
            rain_alert_sent = 0;
        }

        Timer0_Delay_ms(2000);
    }
}
