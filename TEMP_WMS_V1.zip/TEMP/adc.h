#ifndef ADC_H
#define ADC_H

/* Initialize ADC interface */
void ADC_Init(void);

/* Read one channel of MCP3204 */
unsigned int MCP3204_Read(unsigned char channel);

#endif
