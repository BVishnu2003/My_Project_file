#ifndef SENSORS_H
#define SENSORS_H

/* =========================================================
   Sensor Data Structure
   ========================================================= */

typedef struct
{
    float temperature;          /* Temperature in Celsius */

    unsigned int soilMoisture;  /* Soil moisture % */

    unsigned int rainfall;      /* Rainfall % */

    unsigned int light;         /* Light intensity % */

} SensorData;


/* =========================================================
   Sensor Functions
   ========================================================= */

/* Read LM35 temperature */
float Read_Temperature(void);

/* Read soil moisture */
unsigned int Read_SoilMoisture(void);

/* Read rain sensor */
unsigned int Read_RainSensor(void);

/* Read LDR */
unsigned int Read_Light(void);


/* =========================================================
   LCD Display Function
   ========================================================= */


void Display_SensorData(SensorData *data);

#endif
