adc.o: adc.c
adc.o: adc.h
adc.o: spi.h
adc.o: config.h
