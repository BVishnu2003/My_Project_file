#ifndef CONFIG_H
#define CONFIG_H

/* =========================================================
   LPC2129 Weather Monitoring System
   Configuration File
   ========================================================= */

/* CPU Clock */
#define FOSC                12000000UL
#define CCLK                60000000UL

/* =========================================================
   MCP3204 ADC Channels
   ========================================================= */

#define TEMP_CHANNEL       0
#define RAIN_CHANNEL       1
#define SOIL_CHANNEL       2
#define LDR_CHANNEL        3

/* MCP3204 Reference Voltage */
#define ADC_VREF           3.3f

/* MCP3204 Resolution */
#define ADC_MAX_VALUE      4095.0f

/* =========================================================
   Sensor Thresholds
   ========================================================= */

/* Temperature in Celsius */
#define TEMP_HIGH_LIMIT    40.0f

/* Soil moisture percentage */
#define SOIL_LOW_LIMIT     30

/* Rain sensor percentage */
#define RAIN_LIMIT         70

/* Light intensity percentage */
#define LIGHT_LOW_LIMIT    20

/* =========================================================
   GSM Configuration
   ========================================================= */

/* Change this to the user's mobile number */
#define PHONE_NUMBER       "9876543210"

/* GSM UART baud rate */
#define GSM_BAUDRATE       9600

/* =========================================================
   Monitoring Interval
   ========================================================= */

#define SENSOR_INTERVAL_MS 5000

/* =========================================================
   GPIO Definitions
   Modify these according to your circuit
   ========================================================= */

/* LED */
#define LED_ON             1
#define LED_OFF            0

/* Buzzer */
#define BUZZER_ON          1
#define BUZZER_OFF         0

/* =========================================================
   System Status
   ========================================================= */

#define NORMAL_STATUS      0
#define ALERT_STATUS       1

#endif
