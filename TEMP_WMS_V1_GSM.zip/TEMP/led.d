led.o: led.c
led.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
led.o: led.h
