#include <LPC21xx.h>
#include "buzzer.h"

#define BUZZER_PIN 11

void BUZZER_INIT(void)
{
    IODIR0 |= (1 << BUZZER_PIN);
    IOCLR0 = (1 << BUZZER_PIN);
}

void BUZZER_HIGH(void)
{
    IOSET0 = (1 << BUZZER_PIN);
}

void BUZZER_LOW(void)
{
    IOCLR0 = (1 << BUZZER_PIN);
}
