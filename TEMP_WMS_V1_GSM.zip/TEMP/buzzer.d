buzzer.o: buzzer.c
buzzer.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
buzzer.o: buzzer.h
