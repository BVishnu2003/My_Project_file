adc.o: adc.c
adc.o: adc.h
adc.o: spi.h
adc.o: config.h
adc.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
