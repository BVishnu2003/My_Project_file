sensor.o: sensor.c
sensor.o: sensor.h
sensor.o: adc.h
sensor.o: config.h
sensor.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
sensor.o: lcd.h
sensor.o: timer.h
