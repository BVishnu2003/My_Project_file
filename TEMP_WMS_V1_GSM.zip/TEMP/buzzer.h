#ifndef BUZZER_H
#define BUZZER_H

void BUZZER_INIT(void);
void BUZZER_HIGH(void);
void BUZZER_LOW(void);

#endif
