led.o: led.c
led.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
led.o: led.h
