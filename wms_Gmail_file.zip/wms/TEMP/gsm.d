gsm.o: gsm.c
gsm.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
gsm.o: uart.h
gsm.o: gsm.h
gsm.o: timer.h
