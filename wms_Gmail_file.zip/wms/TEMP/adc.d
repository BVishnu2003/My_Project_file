adc.o: adc.c
adc.o: adc.h
adc.o: spi.h
adc.o: config.h
adc.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
