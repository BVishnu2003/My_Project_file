spi.o: spi.c
spi.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
spi.o: spi.h
