lcd.o: lcd.c
lcd.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
lcd.o: lcd.h
lcd.o: timer.h
