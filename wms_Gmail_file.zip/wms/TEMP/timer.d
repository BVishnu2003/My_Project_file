timer.o: timer.c
timer.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
timer.o: config.h
timer.o: timer.h
