#include <LPC21xx.h>
#include "lcd.h"
#include "timer.h"


/* =========================================================
   16x2 LCD - 4 BIT MODE

   LCD CONNECTIONS

   LCD D4 -> P1.20
   LCD D5 -> P1.21
   LCD D6 -> P1.22
   LCD D7 -> P1.23

   LCD RS -> P1.24
   LCD RW -> GND
   LCD EN -> P1.26
   ========================================================= */


/* LCD data starts from P1.20 */
#define LCD_DATA_SHIFT     20

/* Control pins */
#define LCD_RS             (1 << 24)
#define LCD_EN             (1 << 26)


/* =========================================================
   Send 4 bits to LCD
   ========================================================= */

static void LCD_SendNibble(unsigned char nibble)
{
    /* Clear P1.20-P1.23 */
    IO1CLR = (0x0F << LCD_DATA_SHIFT);

    /* Put lower 4 bits on D4-D7 */
    IO1SET = ((unsigned long)(nibble & 0x0F)
              << LCD_DATA_SHIFT);

    /* Enable pulse */
    IO1SET = LCD_EN;

    Timer0_Delay_ms(1);

    IO1CLR = LCD_EN;

    Timer0_Delay_ms(1);
}


/* =========================================================
   LCD Initialization
   ========================================================= */

void LCD_Init(void)
{
    /* Configure P1.20-P1.23 as output */
    IO1DIR |= (0x0F << LCD_DATA_SHIFT);

    /* RS and EN as output */
    IO1DIR |= LCD_RS;
    IO1DIR |= LCD_EN;

    /* Initial state */
    IO1CLR = (0x0F << LCD_DATA_SHIFT);
    IO1CLR = LCD_RS;
    IO1CLR = LCD_EN;

    /* LCD power-up delay */
    Timer0_Delay_ms(20);


    /* =====================================================
       LCD starts in 8-bit mode

       Send 0x03 three times
       ===================================================== */

    LCD_SendNibble(0x03);

    Timer0_Delay_ms(5);

    LCD_SendNibble(0x03);

    Timer0_Delay_ms(1);

    LCD_SendNibble(0x03);

    Timer0_Delay_ms(1);


    /* Change LCD to 4-bit mode */
    LCD_SendNibble(0x02);

    Timer0_Delay_ms(1);


    /* Function Set
       4-bit
       2 lines
       5x7 font */
    LCD_Command(0x28);


    /* Display ON
       Cursor OFF
       Blink OFF */
    LCD_Command(0x0C);


    /* Entry mode
       Cursor moves right */
    LCD_Command(0x06);


    /* Clear display */
    LCD_Command(0x01);

    Timer0_Delay_ms(2);
}


/* =========================================================
   Send Command
   ========================================================= */

void LCD_Command(unsigned char cmd)
{
    /* RS = 0 : Command mode */
    IO1CLR = LCD_RS;

    /* Upper nibble */
    LCD_SendNibble(cmd >> 4);

    /* Lower nibble */
    LCD_SendNibble(cmd & 0x0F);

    Timer0_Delay_ms(2);
}


/* =========================================================
   Send Data / Character
   ========================================================= */

void LCD_Data(unsigned char data)
{
    /* RS = 1 : Data mode */
    IO1SET = LCD_RS;

    /* Upper nibble */
    LCD_SendNibble(data >> 4);

    /* Lower nibble */
    LCD_SendNibble(data & 0x0F);

    Timer0_Delay_ms(1);
}


/* =========================================================
   Display String
   ========================================================= */

void LCD_String(char *str)
{
    while (*str != '\0')
    {
        LCD_Data(*str);
        str++;
    }
}


/* =========================================================
   Clear LCD
   ========================================================= */

void LCD_Clear(void)
{
    LCD_Command(0x01);

    Timer0_Delay_ms(2);
}


/* =========================================================
   Set Cursor
   ========================================================= */

void LCD_SetCursor(unsigned char row, unsigned char column)
{
    unsigned char address;

    if (row == 1)
        address = 0x80 + (column - 1);
    else if (row == 2)
        address = 0xC0 + (column - 1);
    else if (row == 3)
        address = 0x94 + (column - 1);
    else
        address = 0xD4 + (column - 1);

    LCD_Command(address);
}

/* =========================================================
   Display Integer
   ========================================================= */

void LCD_PrintNumber(unsigned int num)
{
    char buffer[10];
    int i = 0;

    if (num == 0)
    {
        LCD_Data('0');
        return;
    }

    while (num > 0)
    {
        buffer[i] = (num % 10) + '0';

        num = num / 10;

        i++;
    }

    while (i > 0)
    {
        i--;

        LCD_Data(buffer[i]);
    }
}


/* =========================================================
   Display Float
   ========================================================= */

void LCD_PrintFloat(float num)
{
    unsigned int integerPart;
    unsigned int decimalPart;

    /* Integer part */
    integerPart = (unsigned int)num;

    /* Two decimal places */
    decimalPart =
        (unsigned int)((num - integerPart) * 100);

    LCD_PrintNumber(integerPart);

    LCD_Data('.');

    if (decimalPart < 10)
    {
        LCD_Data('0');
    }

    LCD_PrintNumber(decimalPart);
}
