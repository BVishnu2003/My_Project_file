#include "config.h"
#include "timer.h"
#include "adc.h"
#include "lcd.h"
#include "sensor.h"

int main(void)
{
    float temperature;
    unsigned int rain;
    unsigned int soil;
    unsigned int light;

    Timer0_Init();
    LCD_Init();
    ADC_Init();

    /* Power ON Title */
    LCD_Clear();

    LCD_String("WEATHER MONITOR");
	  Timer0_Delay_ms(1000);

     LCD_Clear();
    LCD_String("SYSTEM STARTING");

    Timer0_Delay_ms(1000);

    while (1)
    {
        temperature = Read_Temperature();
        rain = Read_RainSensor();
        soil = Read_SoilMoisture();
        light = Read_Light();

        LCD_Clear();

        LCD_String("TEMP:");
        LCD_PrintFloat(temperature);
        LCD_Data('C');

        LCD_SetCursor(2, 1);
        LCD_String("RAIN:");
        LCD_PrintNumber(rain);
        LCD_Data('%');

        LCD_SetCursor(3, 1);
        LCD_String("SOIL:");
        LCD_PrintNumber(soil);
        LCD_Data('%');

        LCD_SetCursor(4, 1);
        LCD_String("LIGHT:");
        LCD_PrintNumber(light);
        LCD_Data('%');

        Timer0_Delay_ms(2000);
    }
}

