main.o: main.c
main.o: config.h
main.o: timer.h
main.o: adc.h
main.o: lcd.h
main.o: sensor.h
