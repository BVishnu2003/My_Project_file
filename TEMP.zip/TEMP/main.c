#include "config.h"
#include "timer.h"
#include "adc.h"
#include "lcd.h"
#include "sensor.h"

int main(void)
{
    float temperature;

    Timer0_Init();

    LCD_Init();

    ADC_Init();

    while (1)
    {
        temperature = Read_Temperature();

        LCD_Clear();

        LCD_String("TEMPERATURE:");

        LCD_SetCursor(2, 1);

        LCD_PrintFloat(temperature);

        LCD_Data('C');

        Timer0_Delay_ms(2000);
    }
}
